package com.mycompany.test;

public class PiggyBank {
    private double savings;

    public PiggyBank(double initialSavings) {
        this.savings = initialSavings;
    }

    public double getSavings() {
        return savings;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be greater than zero.");
        }
        savings += amount;
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        }
        if (amount > savings) {
            throw new IllegalArgumentException("Insufficient savings in PiggyBank.");
        }
        savings -= amount;
    }
}
