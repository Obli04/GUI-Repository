package com.mycompany.test;

public class TransactionService {

    public static void sendMoney(Account sender, Account receiver, double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Transfer amount must be greater than zero.");
        }
        if (sender.getBalance() < amount) {
            throw new IllegalArgumentException("Insufficient balance in sender's account.");
        }

        sender.withdraw(amount);
        receiver.deposit(amount);

        System.out.println("Transaction successful! " + amount + " transferred from "
                + sender.getAccountId() + " to " + receiver.getAccountId());
    }
}
